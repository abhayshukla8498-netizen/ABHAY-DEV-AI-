package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class Project(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val type: String, // "WEBSITE" or "ANDROID_APP"
    val prompt: String,
    val sourceCode: String, // The actual clean source code (HTML/JS or Kotlin/Compose)
    val previewConfigJson: String, // JSON describing the visual component tree for Android simulation, or HTML for WebView
    val timestamp: Long = System.currentTimeMillis(),
    val isPublished: Boolean = false,
    val publishedUrl: String = ""
)
