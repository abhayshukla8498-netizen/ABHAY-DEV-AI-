package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data.AppDatabase
import com.example.data.ProjectRepository
import com.example.ui.ProjectViewModel
import com.example.ui.ProjectViewModelFactory
import com.example.ui.screens.CreatorScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PublisherScreen
import com.example.ui.screens.WorkspaceScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Enable edge-to-edge rendering for full bleed layout content
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    AppNavigation(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

// Route identifiers conforming to navigation design guidelines
private const val ROUTE_SPLASH = "splash"
private const val ROUTE_LOGIN = "login"
private const val ROUTE_HOME = "home"
private const val ROUTE_CREATOR = "creator"
private const val ROUTE_WORKSPACE = "workspace"
private const val ROUTE_PUBLISHER = "publisher"

@Composable
fun AppNavigation(
    modifier: Modifier = Modifier
) {
    val navController = rememberNavController()

    // Initialize Room DB & repository instance
    val context = androidx.compose.ui.platform.LocalContext.current
    val database = AppDatabase.getDatabase(context.applicationContext)
    val repository = ProjectRepository(database.projectDao())
    val application = context.applicationContext as android.app.Application
    
    val viewModelFactory = ProjectViewModelFactory(application, repository)
    val viewModel: ProjectViewModel = viewModel(factory = viewModelFactory)

    // Secure Reactive Session Observer
    val isLoggedIn by viewModel.isLoggedIn.collectAsState()
    LaunchedEffect(isLoggedIn) {
        if (!isLoggedIn) {
            val currentRoute = navController.currentBackStackEntry?.destination?.route
            if (currentRoute != ROUTE_LOGIN && currentRoute != ROUTE_SPLASH) {
                navController.navigate(ROUTE_LOGIN) {
                    popUpTo(0) { inclusive = true }
                }
            }
        }
    }

    NavHost(
        navController = navController,
        startDestination = ROUTE_SPLASH,
        modifier = modifier
    ) {
        composable(ROUTE_SPLASH) {
            SplashScreen(
                onNavigateToHome = {
                    val destination = if (viewModel.isLoggedIn.value) ROUTE_HOME else ROUTE_LOGIN
                    navController.navigate(destination) {
                        popUpTo(ROUTE_SPLASH) { inclusive = true }
                    }
                }
            )
        }

        composable(ROUTE_LOGIN) {
            LoginScreen(
                viewModel = viewModel,
                onNavigateToHome = {
                    navController.navigate(ROUTE_HOME) {
                        popUpTo(ROUTE_LOGIN) { inclusive = true }
                    }
                }
            )
        }

        composable(ROUTE_HOME) {
            HomeScreen(
                viewModel = viewModel,
                onNavigateToCreator = {
                    viewModel.selectProject(null) // Reset selection for a fresh build
                    navController.navigate(ROUTE_CREATOR)
                },
                onNavigateToWorkspace = {
                    navController.navigate(ROUTE_WORKSPACE)
                },
                onNavigateToPublisher = {
                    navController.navigate(ROUTE_PUBLISHER)
                }
            )
        }

        composable(ROUTE_CREATOR) {
            CreatorScreen(
                viewModel = viewModel,
                onNavigateBack = {
                    navController.popBackStack()
                },
                onNavigateToWorkspace = {
                    // Navigate to the Workspace and clear Creator from backstack so back button goes directly to Home
                    navController.navigate(ROUTE_WORKSPACE) {
                        popUpTo(ROUTE_HOME)
                    }
                }
            )
        }

        composable(ROUTE_WORKSPACE) {
            WorkspaceScreen(
                viewModel = viewModel,
                onNavigateBack = {
                    navController.navigate(ROUTE_HOME) {
                        popUpTo(ROUTE_HOME) { inclusive = true }
                    }
                }
            )
        }

        composable(ROUTE_PUBLISHER) {
            PublisherScreen(
                viewModel = viewModel,
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}
