package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashScreen(
    onNavigateToHome: () -> Unit
) {
    // Animation states
    val logoScale = remember { Animatable(0.2f) }
    val logoRotation = remember { Animatable(0f) }
    val glowScale = remember { Animatable(0.8f) }
    val glowAlpha = remember { Animatable(0.6f) }
    val textAlpha = remember { Animatable(0f) }
    val textOffsetY = remember { Animatable(30f) }
    val subtitleAlpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        // 1. Animate Logo Scale with bounce/spring effect using custom tween easing
        launch {
            logoScale.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 1500, easing = { t ->
                    val s = 1.70158f
                    val p = t - 1f
                    p * p * ((s + 1f) * p + s) + 1f
                })
            )
        }

        // 2. Logo rotation
        launch {
            logoRotation.animateTo(
                targetValue = 360f,
                animationSpec = tween(durationMillis = 1600, easing = LinearEasing)
            )
        }

        // 3. Infinite glowing wave pulse
        launch {
            glowScale.animateTo(
                targetValue = 2.0f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 2000, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                )
            )
        }
        launch {
            glowAlpha.animateTo(
                targetValue = 0f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 2000, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                )
            )
        }

        // 4. Fade in and slide up text title "ABHAY DEV AI" after 1 second
        launch {
            delay(1000)
            launch {
                textAlpha.animateTo(
                    targetValue = 1f,
                    animationSpec = tween(durationMillis = 1200)
                )
            }
            launch {
                textOffsetY.animateTo(
                    targetValue = 0f,
                    animationSpec = tween(durationMillis = 1200)
                )
            }
        }

        // 5. Fade in subtitle "FEARLESS. CREATIVE. INTELLIGENT." after 2200ms
        launch {
            delay(2200)
            subtitleAlpha.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 1200)
            )
        }

        // 6. Total 5-second delay before navigating to home
        delay(5000)
        onNavigateToHome()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(24.dp)
        ) {
            // Logo container
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(240.dp)
            ) {
                // Pulsing outer glowing radial circle
                Box(
                    modifier = Modifier
                        .size(120.dp)
                        .scale(glowScale.value)
                        .alpha(glowAlpha.value)
                        .background(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    Color(0xFF00E5FF).copy(alpha = 0.4f),
                                    Color(0xFF2979FF).copy(alpha = 0.15f),
                                    Color.Transparent
                                )
                            ),
                            shape = CircleShape
                        )
                )

                // Actual logo image with animated scale, rotation, and alpha
                Image(
                    painter = painterResource(id = R.drawable.ic_app_logo),
                    contentDescription = "ABHAY DEV AI Logo",
                    modifier = Modifier
                        .size(140.dp)
                        .scale(logoScale.value)
                        .graphicsLayer(rotationZ = logoRotation.value)
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Main Brand Title
            Text(
                text = "ABHAY DEV AI",
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                color = Color.Black,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .alpha(textAlpha.value)
                    .offset(y = textOffsetY.value.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Brand Tagline / Subtitle
            Text(
                text = "FEARLESS. CREATIVE. INTELLIGENT.",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1E293B),
                letterSpacing = 2.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .alpha(subtitleAlpha.value)
            )
        }
    }
}
