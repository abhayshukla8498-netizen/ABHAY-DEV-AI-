package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.ProjectViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    viewModel: ProjectViewModel,
    onNavigateToHome: () -> Unit
) {
    val SineEasing = CubicBezierEasing(0.445f, 0.05f, 0.55f, 0.95f)
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    // Session switching state: true = Sign Up, false = Login
    var isSignUp by remember { mutableStateOf(false) }

    // Input States
    var nameInput by remember { mutableStateOf("") }
    var emailInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }

    // Handshake Authentication States
    var isAuthenticating by remember { mutableStateOf(false) }
    var authStepText by remember { mutableStateOf("Initializing secure handshake...") }
    val authProgress = remember { Animatable(0f) }

    // Animated Enter Entrance Sequence
    var startAnimations by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(150)
        startAnimations = true
    }

    // Interactive custom game-loop animation state for dynamic space background
    val transitionState = rememberInfiniteTransition(label = "CosmicBackground")
    val cosmicRotation by transitionState.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(40000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "CosmicRotation"
    )

    // Floating particles state on canvas
    val particleCount = 20
    val particles = remember {
        List(particleCount) {
            ParticleData(
                xSeed = (0..100).random() / 100f,
                ySeed = (0..100).random() / 100f,
                radius = (3..8).random().toFloat(),
                speed = (10000..20000).random(),
                pulseSpeed = (1500..3500).random()
            )
        }
    }

    // Floating UI Orbs animations (Dynamic Y offset)
    val floatAnim1 by transitionState.animateFloat(
        initialValue = -15f,
        targetValue = 15f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = SineEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Float1"
    )

    val floatAnim2 by transitionState.animateFloat(
        initialValue = 12f,
        targetValue = -12f,
        animationSpec = infiniteRepeatable(
            animation = tween(5500, easing = SineEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Float2"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070B14)) // Rich Cosmic Ultra Dark background
    ) {
        // LAYER 1: Animated Nebula/Galaxy Radial Gradients
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(rotationZ = cosmicRotation)
        ) {
            val width = size.width
            val height = size.height

            // Core Cosmic Center Gradient
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF7B1FA2).copy(alpha = 0.25f), // Nebula violet
                        Color(0xFF00E5FF).copy(alpha = 0.12f), // Cyan glow
                        Color.Transparent
                    ),
                    center = Offset(width * 0.35f, height * 0.4f),
                    radius = width * 0.8f
                )
            )

            // Secondary Aurora/Nebula Gradient
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF2979FF).copy(alpha = 0.22f), // Royal blue glow
                        Color(0xFFD500F9).copy(alpha = 0.08f), // Deep Magenta
                        Color.Transparent
                    ),
                    center = Offset(width * 0.7f, height * 0.7f),
                    radius = width * 0.7f
                )
            )
        }

        // LAYER 2: Floating Cosmic Particles (Game-Loop Canvas)
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val time = System.currentTimeMillis()

            particles.forEach { p ->
                // Compute movement based on seed offsets and sine waves
                val elapsed = time % p.speed
                val progress = elapsed.toFloat() / p.speed
                val x = (p.xSeed + 0.15f * sin(progress * 2 * Math.PI.toFloat())) * width
                val y = ((p.ySeed + progress) % 1.0f) * height

                // Pulsing Alpha animation
                val pulseElapsed = time % p.pulseSpeed
                val pulseProgress = pulseElapsed.toFloat() / p.pulseSpeed
                val alpha = 0.2f + 0.5f * (0.5f + 0.5f * cos(pulseProgress * 2 * Math.PI.toFloat()))

                drawCircle(
                    color = Color(0xFF00E5FF).copy(alpha = alpha),
                    radius = p.radius,
                    center = Offset(x, y)
                )
            }
        }

        // LAYER 3: 3D Floating Glowing Blurry Spheres in background
        Box(
            modifier = Modifier
                .offset(x = (-30).dp, y = (100).dp + floatAnim1.dp)
                .size(160.dp)
                .blur(50.dp)
                .background(Color(0xFFD500F9).copy(alpha = 0.25f), CircleShape)
        )
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .offset(x = 40.dp, y = (-80).dp + floatAnim2.dp)
                .size(180.dp)
                .blur(60.dp)
                .background(Color(0xFF2979FF).copy(alpha = 0.25f), CircleShape)
        )

        // LAYER 4: Foreground Interactive UI Column
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Animated Header Row
            AnimatedVisibility(
                visible = startAnimations,
                enter = slideInVertically(
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessLow
                    )
                ) { -200 } + fadeIn(animationSpec = tween(600)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    // Futuristic glowing hexagon shape for app logo
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(StudioTeal, StudioBlue, StudioPurple)
                                )
                            )
                            .border(1.5.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Cosmic Icon",
                            tint = Color.White,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "ABHAY DEV AI",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = "The Future of AI App Generation",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = StudioTeal,
                        letterSpacing = 1.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Main Credential Interactive Container
            AnimatedVisibility(
                visible = startAnimations,
                enter = scaleIn(
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessLow
                    )
                ) + fadeIn(animationSpec = tween(700)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Card(
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFF131A2E).copy(alpha = 0.85f)
                    ),
                    border = CardDefaults.outlinedCardBorder(true).copy(
                        brush = Brush.horizontalGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.15f),
                                Color.White.copy(alpha = 0.03f)
                            )
                        )
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .blur(if (isAuthenticating) 2.dp else 0.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Title for Card
                        Text(
                            text = if (isSignUp) "Create Creator Account" else "Welcome Back Creator",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )

                        Text(
                            text = if (isSignUp) "Enter details to get your free AI tokens" else "Sign in to access your saved websites & apps",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.6f),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
                        )

                        // 1. Dynamic Optional Name Field
                        AnimatedVisibility(
                            visible = isSignUp,
                            enter = expandVertically() + fadeIn(),
                            exit = shrinkVertically() + fadeOut()
                        ) {
                            Column {
                                OutlinedTextField(
                                    value = nameInput,
                                    onValueChange = { nameInput = it },
                                    label = { Text("Full Name") },
                                    placeholder = { Text("Abhay Shukla") },
                                    leadingIcon = {
                                        Icon(Icons.Default.Person, contentDescription = "Name", tint = StudioTeal)
                                    },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White.copy(alpha = 0.9f),
                                        focusedBorderColor = StudioTeal,
                                        unfocusedBorderColor = Color.White.copy(alpha = 0.12f),
                                        focusedLabelColor = StudioTeal,
                                        unfocusedLabelColor = Color.White.copy(alpha = 0.5f),
                                        focusedLeadingIconColor = StudioTeal,
                                        unfocusedLeadingIconColor = Color.White.copy(alpha = 0.4f)
                                    ),
                                    shape = RoundedCornerShape(16.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(bottom = 12.dp)
                                )
                            }
                        }

                        // 2. Email Field
                        OutlinedTextField(
                            value = emailInput,
                            onValueChange = { emailInput = it },
                            label = { Text("Email Address") },
                            placeholder = { Text("example@gmail.com") },
                            leadingIcon = {
                                Icon(Icons.Default.Email, contentDescription = "Email", tint = StudioBlue)
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Email,
                                imeAction = ImeAction.Next
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White.copy(alpha = 0.9f),
                                focusedBorderColor = StudioBlue,
                                unfocusedBorderColor = Color.White.copy(alpha = 0.12f),
                                focusedLabelColor = StudioBlue,
                                unfocusedLabelColor = Color.White.copy(alpha = 0.5f),
                                focusedLeadingIconColor = StudioBlue,
                                unfocusedLeadingIconColor = Color.White.copy(alpha = 0.4f)
                            ),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // 3. Password Field
                        OutlinedTextField(
                            value = passwordInput,
                            onValueChange = { passwordInput = it },
                            label = { Text("Password") },
                            placeholder = { Text("••••••••") },
                            leadingIcon = {
                                Icon(Icons.Default.Lock, contentDescription = "Password", tint = StudioPurple)
                            },
                            trailingIcon = {
                                val image = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff
                                IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                    Icon(image, contentDescription = "Toggle password visibility", tint = Color.White.copy(alpha = 0.5f))
                                }
                            },
                            singleLine = true,
                            visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Password,
                                imeAction = ImeAction.Done
                            ),
                            keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White.copy(alpha = 0.9f),
                                focusedBorderColor = StudioPurple,
                                unfocusedBorderColor = Color.White.copy(alpha = 0.12f),
                                focusedLabelColor = StudioPurple,
                                unfocusedLabelColor = Color.White.copy(alpha = 0.5f),
                                focusedLeadingIconColor = StudioPurple,
                                unfocusedLeadingIconColor = Color.White.copy(alpha = 0.4f)
                            ),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        // 4. Authenticate & Handshake Action Button
                        val authScope = rememberCoroutineScope()
                        val interactionSource = remember { MutableInteractionSource() }
                        val isPressed by interactionSource.collectIsPressedAsState()
                        val btnScale by animateFloatAsState(
                            targetValue = if (isPressed) 0.93f else 1.0f,
                            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
                            label = "SubmitBtnScale"
                        )

                        Box(
                            modifier = Modifier
                                .scale(btnScale)
                                .fillMaxWidth()
                                .height(52.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(StudioBlue, StudioPurple)
                                    )
                                )
                                .clickable(
                                    interactionSource = interactionSource,
                                    indication = null,
                                    enabled = !isAuthenticating,
                                    onClick = {
                                        if (emailInput.isBlank() || passwordInput.isBlank() || (isSignUp && nameInput.isBlank())) {
                                            Toast.makeText(context, "Please fill in all details! ⚠️", Toast.LENGTH_SHORT).show()
                                            return@clickable
                                        }
                                        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(emailInput).matches()) {
                                            Toast.makeText(context, "Please enter a valid email! 📧", Toast.LENGTH_SHORT).show()
                                            return@clickable
                                        }
                                        if (passwordInput.length < 6) {
                                            Toast.makeText(context, "Password must be at least 6 characters! 🔒", Toast.LENGTH_SHORT).show()
                                            return@clickable
                                        }

                                        keyboardController?.hide()
                                        focusManager.clearFocus()

                                        authScope.launch {
                                            isAuthenticating = true
                                            val email = emailInput.trim()
                                            val password = passwordInput
                                            val name = nameInput.trim()

                                            if (isSignUp) {
                                                authStepText = "Creating account on Firebase..."
                                                authProgress.animateTo(0.3f, animationSpec = tween(500, easing = FastOutSlowInEasing))
                                                
                                                val firebaseAuth = com.google.firebase.auth.FirebaseAuth.getInstance()
                                                firebaseAuth.createUserWithEmailAndPassword(email, password)
                                                    .addOnCompleteListener { task ->
                                                        if (task.isSuccessful) {
                                                            authScope.launch {
                                                                authStepText = "Setting up user profile..."
                                                                authProgress.animateTo(0.7f, animationSpec = tween(400, easing = FastOutSlowInEasing))
                                                                
                                                                val user = firebaseAuth.currentUser
                                                                val profileUpdates = com.google.firebase.auth.UserProfileChangeRequest.Builder()
                                                                    .setDisplayName(name)
                                                                    .build()
                                                                user?.updateProfile(profileUpdates)
                                                                    ?.addOnCompleteListener { updateTask ->
                                                                        authScope.launch {
                                                                            authStepText = "Syncing local databases..."
                                                                            authProgress.animateTo(1.0f, animationSpec = tween(400, easing = EaseOutBounce))
                                                                            
                                                                            viewModel.loginUser(email, name)
                                                                            Toast.makeText(context, "Welcome $name! Account created successfully! 🎉", Toast.LENGTH_LONG).show()
                                                                            isAuthenticating = false
                                                                            onNavigateToHome()
                                                                        }
                                                                    } ?: run {
                                                                        viewModel.loginUser(email, name)
                                                                        isAuthenticating = false
                                                                        onNavigateToHome()
                                                                    }
                                                            }
                                                        } else {
                                                            isAuthenticating = false
                                                            val errorMsg = task.exception?.localizedMessage ?: "Registration failed!"
                                                            Toast.makeText(context, "$errorMsg ❌", Toast.LENGTH_LONG).show()
                                                        }
                                                    }
                                            } else {
                                                authStepText = "Verifying credentials with Firebase..."
                                                authProgress.animateTo(0.4f, animationSpec = tween(500, easing = FastOutSlowInEasing))
                                                
                                                val firebaseAuth = com.google.firebase.auth.FirebaseAuth.getInstance()
                                                firebaseAuth.signInWithEmailAndPassword(email, password)
                                                    .addOnCompleteListener { task ->
                                                        if (task.isSuccessful) {
                                                            authScope.launch {
                                                                val user = firebaseAuth.currentUser
                                                                val userName = user?.displayName ?: email.substringBefore("@")
                                                                 
                                                                authStepText = "Success! Loading your workspace..."
                                                                authProgress.animateTo(1.0f, animationSpec = tween(500, easing = EaseOutBounce))
                                                                 
                                                                viewModel.loginUser(email, userName)
                                                                Toast.makeText(context, "Welcome back $userName! 🎉", Toast.LENGTH_LONG).show()
                                                                isAuthenticating = false
                                                                onNavigateToHome()
                                                            }
                                                        } else {
                                                            isAuthenticating = false
                                                            val errorMsg = task.exception?.localizedMessage ?: "Authentication failed!"
                                                            Toast.makeText(context, "$errorMsg ❌", Toast.LENGTH_LONG).show()
                                                        }
                                                    }
                                            }
                                        }
                                    }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = if (isSignUp) Icons.Default.GroupAdd else Icons.Default.Login,
                                    contentDescription = "Submit Icon",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = if (isSignUp) "CREATE CREATOR PORTAL" else "ENTER CREATOR PORTAL",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White,
                                    letterSpacing = 1.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Switch between Login & Signup
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    if (!isAuthenticating) {
                                        isSignUp = !isSignUp
                                    }
                                }
                                .padding(8.dp)
                        ) {
                            Text(
                                text = if (isSignUp) "Already have an account? " else "Don't have an account? ",
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.5f)
                            )
                            Text(
                                text = if (isSignUp) "Sign In" else "Sign Up",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = StudioTeal
                            )
                        }

                        // Simulated Guest Access
                        if (!isSignUp) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Guest Login with any demo email/password is allowed!",
                                fontSize = 10.sp,
                                color = StudioTeal.copy(alpha = 0.8f),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        // LAYER 5: Overlaid Handshake Authentication Progress dialog with futuristic visual styling
        if (isAuthenticating) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.85f)),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .padding(16.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFF0F172A)
                    ),
                    border = BorderStroke(
                        width = 1.dp,
                        brush = Brush.horizontalGradient(
                            colors = listOf(StudioTeal, StudioPurple)
                        )
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        // Custom futuristic rotating radar indicator
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.size(80.dp)
                        ) {
                            CircularProgressIndicator(
                                progress = { authProgress.value },
                                color = StudioTeal,
                                strokeWidth = 3.dp,
                                modifier = Modifier.fillMaxSize()
                            )
                            CircularProgressIndicator(
                                color = StudioPurple,
                                strokeWidth = 1.5.dp,
                                modifier = Modifier
                                    .fillMaxSize(0.7f)
                                    .graphicsLayer(rotationZ = cosmicRotation * 1.5f)
                            )
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = "Shield",
                                tint = StudioTeal,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Text(
                            text = "SECURE PROTOCOL HANDSHAKE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = StudioTeal,
                            letterSpacing = 2.sp,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = authStepText,
                            fontSize = 13.sp,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            minLines = 2,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Linear Glow track
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(Color.White.copy(alpha = 0.1f))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(authProgress.value)
                                    .fillMaxHeight()
                                    .background(
                                        Brush.horizontalGradient(
                                            colors = listOf(StudioBlue, StudioTeal)
                                        )
                                    )
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "${(authProgress.value * 100).toInt()}% Secure Connection Established",
                            fontSize = 10.sp,
                            color = Color.White.copy(alpha = 0.5f)
                        )
                    }
                }
            }
        }
    }
}

// Particle Helper Data Class
data class ParticleData(
    val xSeed: Float,
    val ySeed: Float,
    val radius: Float,
    val speed: Int,
    val pulseSpeed: Int
)
